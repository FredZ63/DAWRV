#!/bin/bash
echo "🏔️  Starting ATLAS..."
echo ""
echo "Installing dependencies..."
npm install
echo ""
echo "Launching ATLAS..."
npm run dev
